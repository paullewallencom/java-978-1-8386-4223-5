CREATE TABLE customers (
    id INT PRIMARY KEY,
    name TEXT
);

INSERT INTO customers VALUES (12, 'John Smith');
INSERT INTO customers VALUES (33, 'Franklin Alder');
INSERT INTO customers VALUES (37, 'Lynda Sheldon');
INSERT INTO customers VALUES (41, 'Logan Michael');
INSERT INTO customers VALUES (67, 'Lorena Clyde');
INSERT INTO customers VALUES (88, 'Peter Styles');
INSERT INTO customers VALUES (102, 'Rupert Gordon');
