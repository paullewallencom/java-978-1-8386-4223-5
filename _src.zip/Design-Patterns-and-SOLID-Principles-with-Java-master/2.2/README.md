# Design Patterns Warehouse Demo

## About

Video course companion code.

## Section 2, Video 2

Nothing has changed since Section 2, Video 1.

**Errata**

* The `Warehouse.addOrder` method contained a bug in the 102th line.
The order ID was generated based on the last product ID.
This is fixed in the code, but you can see this to be different in this video.
