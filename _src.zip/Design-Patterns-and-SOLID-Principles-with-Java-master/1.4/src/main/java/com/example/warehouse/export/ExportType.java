package com.example.warehouse.export;

public enum ExportType {

    TXT,
    CSV;
}
