package com.example.warehouse;

public interface ReportDelivery {

    void deliver();
}
