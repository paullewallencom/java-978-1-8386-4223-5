# Design Patterns Warehouse Demo

## About

Video course companion code.

## Section 1, Video 1

Only contains an empty skeleton.
Go to the next video on branch `1.2` to continue.
