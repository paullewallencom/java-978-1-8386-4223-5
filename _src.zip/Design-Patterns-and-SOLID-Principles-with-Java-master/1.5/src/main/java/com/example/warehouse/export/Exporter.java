package com.example.warehouse.export;

public interface Exporter {

    void export();
}
