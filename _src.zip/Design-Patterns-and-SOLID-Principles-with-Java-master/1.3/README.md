# Design Patterns Warehouse Demo

## About

Video course companion code.

## Section 1, Video 3

Nothing has changed since _Section 1_, _Video 2_.

The previous video explored how _not to_ add new exporter functionality to the project.
Go to the next video on branch `1.4` to continue.
