# Design Patterns Warehouse Demo

## About

Video course companion code.

## Section 4, Video 2

Changes since _Section 4_, _Video 1_.

* Create `Warehouses` "Simple" Factory class.
* Use it in `Main`: remove logic that instantiates `Warehouse` instances and moved it to factory methods in
`Warehouses`.
* Add a simple `WarehouseTest` class that relies on `Warehouses`. 
