# Design Patterns Warehouse Demo

## About

Video course companion code.

## Section 3, Video 1

Changes since _Section 2_, _Video 5_.

* Implemented report export functionality in the `Web` class.
